"""
====================================================================
PROYECTO: SISTEMA DE MONITOREO AMBIENTAL - MONÓMEROS S.A.
MODULO: FIRMWARE DE TELEMETRÍA Y ADQUISICIÓN DE DATOS (ESP32)
INTEGRANTES: GRUPO 8 (4 INTEGRANTES)
LENGUAJE: MICROPYTHON CON ARQUITECTURA ORIENTADA A OBJETOS (POO)
====================================================================
"""

import network
import urequests
import ujson
import utime
import urandom
from machine import Pin, I2C
import dht
from i2c_lcd import I2cLcd

# ==================================================================
# PARTE 1: GESTOR DE COMUNICACIÓN DE RED (WIFI)
# ==================================================================
class NetworkManager:
    """Clase encargada de inicializar y mantener la conexión Wi-Fi."""
    
    def __init__(self, ssid: str, password: str):
        self.ssid = ssid
        self.password = password
        self.wlan = network.WLAN(network.STA_IF)

    def connect(self):
        """Establece la conexión con el Access Point en el simulador."""
        self.wlan.active(True)
        if not self.wlan.isconnected():
            print("[RED] Conectando a red Wi-Fi...")
            self.wlan.connect(self.ssid, self.password)
            intentos = 0
            while not self.wlan.isconnected() and intentos < 10:
                utime.sleep_ms(150)
                intentos += 1
        if self.wlan.isconnected():
            print(f"[RED] Conexión establecida. IP: {self.wlan.ifconfig()[0]}")
        else:
            print("[RED] Modo offline iniciado.")


# ==================================================================
# PARTE 2: CAPA DE ADQUISICIÓN Y SIMULACIÓN COHERENTE DE GAS (MQ)
# ==================================================================
class EnvironmentalSensors:
    """Gestiona la lectura física y conversión lógica de sensores."""
    
    def __init__(self, pin_dht: int):
        self.dht_device = dht.DHT22(Pin(pin_dht))
        self.current_gas_ppm = 45.0  # Nivel base inicial en planta

    def read_telemetry(self):
        """
        Lee el sensor DHT22 y computa la variación lógica de gas amoníaco/CO2:
        - Temperatura: -40 °C a 80 °C (DHT22 real)
        - Humedad: 0% a 100% (DHT22 real)
        - Gas: 15.0 a 650.0 PPM (Simulación lógica coherente)
        """
        try:
            self.dht_device.measure()
            temp_c = self.dht_device.temperature()
            hum_pct = self.dht_device.humidity()
        except Exception:
            temp_c, hum_pct = 25.0, 50.0

        # Simulación de deriva industrial en Monómeros
        delta = (urandom.getrandbits(8) / 255.0 * 6.0) - 3.0
        self.current_gas_ppm += delta

        if self.current_gas_ppm < 15.0:
            self.current_gas_ppm = 15.0
        elif self.current_gas_ppm > 650.0:
            self.current_gas_ppm = 650.0

        return temp_c, hum_pct, self.current_gas_ppm


# ==================================================================
# PARTE 3: GESTOR DE INTERFAZ DE USUARIO (LCD 16X2 Y LEDS)
# ==================================================================
class UserInterfaceManager:
    """Controla la pantalla LCD, los LEDs de estado y los pulsadores."""
    
    def __init__(self, sda_pin: int, scl_pin: int, led_green_pin: int, led_red_pin: int):
        i2c = I2C(0, scl=Pin(scl_pin), sda=Pin(sda_pin), freq=400000)
        self.lcd = I2cLcd(i2c, 0x27, 2, 16)
        
        self.led_green = Pin(led_green_pin, Pin.OUT)
        self.led_red = Pin(led_red_pin, Pin.OUT)
        self.screen_mode = 0

    def show_splash_screen(self):
        """Muestra la pantalla de bienvenida al arrancar el nodo."""
        self.lcd.clear()
        self.lcd.move_to(0, 0)
        self.lcd.putstr("MONOMEROS - G8  ")
        self.lcd.move_to(0, 1)
        self.lcd.putstr("Sistema IoT 2026")
        utime.sleep_ms(1500)
        self.lcd.clear()

    def toggle_screen_mode(self):
        """Alterna entre las diferentes vistas de información en la LCD."""
        self.screen_mode = (self.screen_mode + 1) % 2
        self.lcd.clear()
        print(f"[UI] Pantalla LCD cambiada a modo: {self.screen_mode}")

    def update_indicators(self, is_critical: bool):
        """Actualiza los LEDs según el nivel de riesgo."""
        if is_critical:
            self.led_red.value(1)
            self.led_green.value(0)
        else:
            self.led_red.value(0)
            self.led_green.value(1)

    def show_manual_send_notice(self):
        """Muestra una notificación instantánea en la LCD cuando se pulsa el botón amarillo."""
        self.lcd.clear()
        self.lcd.move_to(0, 0)
        self.lcd.putstr(">> ENVIO MANUAL ")
        self.lcd.move_to(0, 1)
        self.lcd.putstr("TRANSMITIENDO...")
        utime.sleep_ms(600)
        self.lcd.clear()

    def render_display(self, temp: float, hum: float, gas: float, is_critical: bool):
        """Renderiza los datos en la pantalla según el modo seleccionado."""
        if self.screen_mode == 0:
            self.lcd.move_to(0, 0)
            self.lcd.putstr(f"T:{temp:.1f}C H:{hum:.1f}% ")
            self.lcd.move_to(0, 1)
            self.lcd.putstr(f"Gas:{gas:.1f}PPM   ")
        else:
            self.lcd.move_to(0, 0)
            self.lcd.putstr("ESTADO PLANTA:  ")
            self.lcd.move_to(0, 1)
            if is_critical:
                self.lcd.putstr("!EMERGENCIA GAS!")
            else:
                self.lcd.putstr("OPERACION NORMAL")


# ==================================================================
# PARTE 4: CONTROLADOR PRINCIPAL DEL NODO (POO)
# ==================================================================
class MonomerosController:
    """Orquestador central del ciclo de adquisición, alerta y comunicación."""
    
    LIMIT_GAS_PPM = 400.0  # Umbral de gas amoníaco
    LIMIT_TEMP_C = 45.0    # Umbral de sobrecalentamiento

    def __init__(self, api_endpoint: str):
        self.api_endpoint = api_endpoint
        
        self.network = NetworkManager("Wokwi-GUEST", "")
        self.sensors = EnvironmentalSensors(pin_dht=15)
        self.ui = UserInterfaceManager(sda_pin=21, scl_pin=22, led_green_pin=2, led_red_pin=4)
        
        # Pulsadores con pull-up interno
        self.btn_mode = Pin(18, Pin.IN, Pin.PULL_UP)
        self.btn_manual_send = Pin(19, Pin.IN, Pin.PULL_UP)
        
        self.last_btn_mode = 1
        self.last_btn_send = 1
        self.last_transmission_time = utime.ticks_ms()
        self.transmission_interval_ms = 5000

    def transmit_to_api(self, temp: float, hum: float, gas: float, alert: bool):
        """Transmite la trama JSON a la API REST de la base de datos."""
        payload = {
            "id_dispositivo": 1,
            "grupo": 8,
            "temperatura": round(temp, 2),
            "humedad": round(hum, 2),
            "gas_ppm": round(gas, 2),
            "alerta": alert
        }
        print(f"[HTTP] Enviando trama: {payload}")
        try:
            headers = {'Content-Type': 'application/json'}
            res = urequests.post(self.api_endpoint, data=ujson.dumps(payload), headers=headers)
            print(f"[HTTP] Codigo de Respuesta: {res.status_code}")
            res.close()
        except Exception:
            print("[HTTP] API offline o en espera de conexion.")

    def run(self):
        """Bucle principal de ejecución del sistema."""
        self.network.connect()
        self.ui.show_splash_screen()

        while True:
            # 1. Adquisición de telemetría
            temp, hum, gas = self.sensors.read_telemetry()

            # 2. Evaluación de condiciones críticas
            is_critical = (gas > self.LIMIT_GAS_PPM) or (temp > self.LIMIT_TEMP_C)

            # 3. Actualización de interfaz y actuadores
            self.ui.update_indicators(is_critical)
            self.ui.render_display(temp, hum, gas, is_critical)

            # 4. Lectura de pulsador de Modo (Azul - Pin 18)
            current_btn_mode = self.btn_mode.value()
            if current_btn_mode == 0 and self.last_btn_mode == 1:
                self.ui.toggle_screen_mode()
                utime.sleep_ms(150)
            self.last_btn_mode = current_btn_mode

            # 5. Lectura de pulsador de Envío Manual (Amarillo - Pin 19)
            current_btn_send = self.btn_manual_send.value()
            is_manual_trigger = (current_btn_send == 0 and self.last_btn_send == 1)
            self.last_btn_send = current_btn_send

            now = utime.ticks_ms()
            if is_manual_trigger:
                print("[BOTON] Envio manual disparado por Grupo 8.")
                self.ui.show_manual_send_notice()
                self.transmit_to_api(temp, hum, gas, is_critical)
                self.last_transmission_time = now
            elif utime.ticks_diff(now, self.last_transmission_time) >= self.transmission_interval_ms:
                self.last_transmission_time = now
                self.transmit_to_api(temp, hum, gas, is_critical)

            utime.sleep_ms(50)


# ==================================================================
# PUNTO DE ENTRADA AL SISTEMA
# ==================================================================
if __name__ == "__main__":
    API_URL = "http://host.wokwi.internal:8000/api/mediciones"
    node = MonomerosController(API_URL)
    node.run()